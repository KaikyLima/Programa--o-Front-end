/*
5. Realize uma pesquisa rápida sobre o framework NextJS.

O  next é um framework utilizado para criação de sites. Ele possui caracteristicas como conceito de server-slide, rendering e static site generation. O nextjs é basicamente uma continuação do React, sendo seu objetivo a produção de códigos em menos tempo possível
Ele possui uma performace agil, o que serve para deixar as aplicações rapidas.

Principais caracteriscas: 

1 - Criação de back-end de aplicação
2 - Server-slide rendering
3 - Geração de sites estáticos
3 - Sistemas de roteamento
4 - Fast Refresh
5 - divisão de código2

*/