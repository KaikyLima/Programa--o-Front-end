/* 3. Considerando o objeto:

const obj = {

    nome: "Pedro",

    idade: 20,

    curso: "TADS"  

}

Quais são as chaves desse objeto? E os valores?*/

/* As chaves deste objeto é: Nome, Idade e Curso */