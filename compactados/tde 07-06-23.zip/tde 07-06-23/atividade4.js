/* 
4. Sobre React, responda: o que é SPA?

SPA, ou Single Page Application (Aplicação de Página Única), é um modelo de arquitetura de desenvolvimento de software utilizado no React, uma biblioteca JavaScript para a criação de interfaces de usuário. Neste modelo, a aplicação é carregada apenas uma vez no navegador, e a partir dali, as interações do usuário são processados no cliente, sem a necessidade de ficar recarregando a página. 
Basicamente ele atualiza apenas os campos de importancia para o usuário.

*/